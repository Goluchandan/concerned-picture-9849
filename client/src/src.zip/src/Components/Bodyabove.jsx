import React from "react";

function Bodyabove() {
  return (
    <div>
      <h1>Time tracking for better work, not overwork.</h1>
    </div>
  );
}

export default Bodyabove;
