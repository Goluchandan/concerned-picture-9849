import React from "react";

function Product() {
  return (
    <div className="productmaincontainer">
      <div></div>
      <div>A</div>
    </div>
  );
}

export default Product;
